#include <stdio.h>
void block_idct (
	unsigned int src[64],	/* Input block data (de-quantized and pre-scaled for Arai Algorithm) */
	unsigned char dst[64]	/* Pointer to the destination to store the block as byte array */
);
int main(void)
{
	//uart_init();
	//spi_init();
	int tmp[64];
	unsigned char dst[64];
	//tmp=(unsigned int *)0x60060100;
	tmp[0]=25344;
	tmp[1]=-13493;
	tmp[2]=-11122;
	tmp[3]=-8015;
	tmp[4]=-4928;
	tmp[5]=-2515;
	tmp[6]=-970;
	tmp[7]=-212;
	tmp[8]=-4927;
	tmp[9]=-9112;
	tmp[10]=-7018;
	tmp[11]=-4437;
	tmp[12]=-2175;
	tmp[13]=-663;
	tmp[14]=-49;
	tmp[15]=36;
	tmp[16]=2006;
	tmp[17]=3827;
	tmp[18]=3441;
	tmp[19]=2802;
	tmp[20]=2006;
	tmp[21]=1248;
	tmp[22]=588;
	tmp[23]=161;
	tmp[24]=-264;
	tmp[25]=-627;
	tmp[26]=-787;
	tmp[27]=-930;
	tmp[28]=-941;
	tmp[29]=-740;
	tmp[30]=-408;
	tmp[31]=-125;
	tmp[32]=-64;
	tmp[33]=-134;
	tmp[34]=-126;
	tmp[35]=-113;
	tmp[36]=-64;
	tmp[37]=-51;
	tmp[38]=-35;
	tmp[39]=0;
	tmp[40]=0;
	tmp[41]=34;
	tmp[42]=98;
	tmp[43]=177;
	tmp[44]=201;
	tmp[45]=158;
	tmp[46]=81;
	tmp[47]=20;
	tmp[48]=17;
	tmp[49]=48;
	tmp[50]=45;
	tmp[51]=40;
	tmp[52]=34;
	tmp[53]=0;
	tmp[54]=0;
	tmp[55]=0;
	tmp[56]=-9;
	tmp[57]=-25;
	tmp[58]=-47;
	tmp[59]=-42;
	tmp[60]=-53;
	tmp[61]=-42;
	tmp[62]=-29;
	tmp[63]=-8;
	block_idct(tmp,dst);
	for(int i=0;i<64;i++)
	{
		printf("dst[%d]=%d\n",i,dst[i]);
	}
        //while(1);
	//while(1)
	//{
	//	spi_send(0x55);
	//}
	//printf("helloworld\n",0);
	return 0;
}
